# 🎓 Skooly Integration Setup Guide

**Status:** ✅ DEPLOYED & READY FOR TESTING  
**Date:** September 21, 2026 20:40 UTC

---

## 📋 Quick Start

### 1. Configure Skooly Webhook

In your Skooly VIP settings:

1. Go to **Settings** → **Webhooks** (or similar)
2. Add new webhook endpoint:
   ```
   https://mlm-lead-crm.vercel.app/api/webhooks/skooly
   ```
3. Enable all membership-related events
4. Save configuration

### 2. View Captured Events

**Dashboard:** https://mlm-lead-crm.vercel.app/crm/skool-events

- All webhook payloads are captured and displayed
- Raw JSON available for documentation
- Shows matched leads automatically
- Displays processing status

---

## 🎯 What Was Built

### Database Schema Extensions

**Lead table - New fields:**
- `skoolMemberId` - Unique Skool member identifier
- `skoolPlan` - "Standard" or "Premium"
- `skoolMembershipStartedAt` - Timestamp of membership start
- `fullSimulatorResultsUnlocked` - Boolean (set when Standard or Premium)
- `officialCashFlowVisionary` - Boolean (set when Premium only)

**New SkoolEvent table:**
- Captures every webhook event with complete payload
- Matches to Lead by email (normalized)
- Stores raw JSON for documentation
- Tracks processing status and errors

### Webhook Endpoint

**URL:** `POST /api/webhooks/skooly`

**Features:**
- ✅ Logs complete payload to console
- ✅ Stores raw event in database
- ✅ Matches member to existing Lead by email
- ✅ Processes known events (placeholders for now)
- ✅ Always returns 200 OK (prevents retries during testing)
- ✅ Captures errors without failing

**Matching Logic:**
1. Extracts email from webhook (tries multiple field names)
2. Normalizes email (lowercase, trim)
3. Finds existing Lead by email
4. Links SkoolEvent to Lead

### Admin Dashboard

**Page:** `/crm/skool-events`

**Shows:**
- All captured webhook events (newest first)
- Event type and timestamp
- Matched lead info (name, email, current plan)
- Parsed data (email, member ID, plan, status)
- Processing status (✓ processed, ⚠ error)
- Raw JSON payload (expandable)

---

## 🔄 Event Processing Logic

**Current implementation (will be refined after testing):**

### New Member Events
**Triggers:** Event type contains "member", "join", or "created"

**Standard Membership ($0/month):**
- Sets `skoolPlan = "Standard"`
- Sets `fullSimulatorResultsUnlocked = true`
- Records `skoolMembershipStartedAt`

**Premium Membership ($50/year):**
- Sets `skoolPlan = "Premium"`
- Sets `fullSimulatorResultsUnlocked = true`
- Sets `officialCashFlowVisionary = true`
- Records `skoolMembershipStartedAt`

### Upgrade Events
**Triggers:** Event type contains "upgrade" or "premium"

**Action:**
- Updates to `skoolPlan = "Premium"`
- Sets `officialCashFlowVisionary = true`
- Sets `fullSimulatorResultsUnlocked = true`

### Cancellation Events
**Triggers:** Event type contains "cancel", "inactive", or "removed"

**Action:**
- Currently logs only (no state change)
- Decision needed: Remove CFV status? Keep history?

---

## 📝 Testing Checklist

During the 7-day Skooly VIP trial, test these scenarios:

### Test 1: New Standard Member
1. Create Standard ($0/month) membership in Skool
2. Use email that exists in NLC Lead CRM
3. Check `/crm/skool-events` - should show event
4. Check lead record - should show:
   - `skoolPlan: "Standard"`
   - `fullSimulatorResultsUnlocked: true`
   - `officialCashFlowVisionary: false`

### Test 2: New Premium Member
1. Create Premium ($50/year) membership in Skool
2. Use email that exists in NLC Lead CRM
3. Check `/crm/skool-events` - should show event
4. Check lead record - should show:
   - `skoolPlan: "Premium"`
   - `fullSimulatorResultsUnlocked: true`
   - `officialCashFlowVisionary: true`

### Test 3: Standard → Premium Upgrade
1. Start with Standard member
2. Upgrade to Premium
3. Check `/crm/skool-events` - should show upgrade event
4. Check lead record - should now show Premium + CFV status

### Test 4: Membership Cancellation
1. Cancel an active membership
2. Check `/crm/skool-events` - should capture event
3. Document what happens (current: no action taken)

### Test 5: Unknown Email
1. Use email NOT in NLC Lead CRM
2. Check `/crm/skool-events` - event captured but no lead match
3. Document behavior (create lead? ignore?)

---

## 🔍 Documentation Mode

**Goal:** Capture ACTUAL webhook structure before finalizing logic

**What to document:**
1. Exact event type names (e.g., "member.created", "subscription.upgraded")
2. Email field location in payload
3. Member ID field location
4. Plan/tier field values ("Standard", "Premium", "Free", etc.)
5. Status field values ("active", "cancelled", etc.)
6. Any other useful fields

**Where to find it:**
- Console logs (check Vercel deployment logs)
- `/crm/skool-events` page (expand "View Raw Payload")

---

## 🚀 Next Steps (After Testing)

Once we've documented the actual webhook structure:

1. **Refine event processing logic** based on real event names
2. **Add Leads page display** of Skool membership status
3. **Build Resend email sequences:**
   - Welcome sequence for Standard members
   - Welcome sequence for Premium members
   - Upgrade congratulations sequence
   - Results unlock notification
4. **Add filtering** in Leads page by Skool plan
5. **Add stats** to main dashboard (Standard vs Premium members)
6. **Implement cancellation handling** (if needed)

---

## 🛠 Technical Details

**Database Migration:** `20260921203500_add_skooly_integration`
- Applied to production database
- Adds 5 fields to Lead table
- Creates SkoolEvent table
- Adds indexes for performance

**Files Created:**
- `app/api/webhooks/skooly/route.ts` - Webhook endpoint
- `app/crm/skool-events/page.tsx` - Admin dashboard
- `prisma/migrations/20260921203500_add_skooly_integration/migration.sql`

**Deployment:**
- Commit: `2807ae2`
- Live URL: https://mlm-lead-crm.vercel.app
- Webhook: https://mlm-lead-crm.vercel.app/api/webhooks/skooly

---

## ✅ Ready to Test!

1. Activate Skooly VIP 7-day trial
2. Configure webhook URL in Skooly settings
3. Create test memberships
4. View captured events at `/crm/skool-events`
5. Document actual webhook structure
6. Refine automation logic based on findings

**Questions?** Check the webhook endpoint logs in Vercel or the Skool Events dashboard.
